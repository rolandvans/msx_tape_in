import serial
import serial.tools.list_ports

#list all ports
print("Serial ports available:\n")
ports = list(serial.tools.list_ports.comports())
for p in ports:
    print(p)

#select port
port=str(input("Select the port:"))
time=int(input("Number of seconds to record:"))

#read data from port
ser=serial.Serial(port,1000000)
data=ser.read(time*19200)
ser.close()

#save data
f=open('adcrawdata.dat','wb')
f.write(data)
f.close()

print("Data saved\n")